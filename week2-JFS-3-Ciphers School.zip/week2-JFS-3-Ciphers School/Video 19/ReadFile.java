import java.io.BufferReader;
import java.io.FileReader;

public class ReadFile {
    public static void main(String[] args) throws Exception {
        
        
         FileReader fr = new FileReader("Users\shubham raina\Desktop\rhym.txt");
         BufferedReader br = new BufferedReader(fr);

         String line =br.readLine();
         while((line=br.readLine())!=null){
            //System.out.println(line);
            pokemons.add(line);
         }
         System.out.println("Total Pokemons "+ pokemons.size());
         ArrayList<String> pokemonTitles=new ArrayList<String>();
         for(String pok : pokemons){
            String title=pok.split(",")[0];
            pokemonTitles.add(title);
         }
         System.out.println(pokemonTitles);
         
         br.close();
         fr.close();
         
 
    }
}