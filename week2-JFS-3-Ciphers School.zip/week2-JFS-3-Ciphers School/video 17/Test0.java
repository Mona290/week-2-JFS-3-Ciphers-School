import java.util.LinkedList;

public class Test0 {
    
    public static void main(String[] args){
        LinkedList myll=new LinkedList();

        myll.add("Ironman");
        myll.add("Thor");
        myll.add("Hulk");
        myll.add("Loki");

       // System.out.println(myll.get(1));
       myll.addLast("Ganora");
       myll.addLast("AntMan");

       myll.add(2,"Natasha");


        Iterator it = myll.iterator();
        while(it.hashNext()){
            //it.remove();
            System.out.println(it.next());
        }

        System.out.println("-----------");
        System.out.println("whos at the top "+myll.peek());
        System.out.println("hey first one get out "+myll.poll());
        System.out.println("whos standing their at the very last "+myll.peek());
        System.out.println("-----------");

        Iterator it = myll.iterator();
        while(it.hashNext()){
            //it.remove();
            System.out.println(it.next());
        }
    }
}