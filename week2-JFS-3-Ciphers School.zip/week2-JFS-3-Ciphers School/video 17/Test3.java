import java.util.HashSet;
public class Test3{
    public static void main(String[] args){
        //HashSet

        HashSet mySet = new HashSet();

        myset.add("green");
        myset.add("red");
        myset.add("orange");
        myset.add("red");
        myset.add("blue");

        System.out.println(myset);

        LinkedHashSet lhs = new LinkedHashSet();

        lhs.add("green");
        lhs.add("red");
        lhs.add("orange");
        lhs.add("red");
        lhs.add("orange");

        System.out.println(lhs);

        TreeSet ts = new TreeSet();
        // treeset doesnt allows nulls
        // treeset sorts the data in ascending order
        
        lhs.add("cat");
        lhs.add("Apple");
        lhs.add("Ball");
        lhs.add("null");

        System.out.println(ts);

    }
}