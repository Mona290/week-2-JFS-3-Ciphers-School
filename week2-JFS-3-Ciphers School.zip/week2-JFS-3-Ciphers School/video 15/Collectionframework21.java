import java.util.ArrayList;
import java.util.List;
public class Collectionframework21{
    public static void main(String[] args) {
        ArrayList<String> states=new ArrayList<String>();

        states.add("California");
        states.add("Alabama");
        states.add("Alaska");
        states.add("Arkansas");

        System.out.println("ArrayList: "+states);

        String s=states.get(2);
        System.out.println("I got "+s);
        //System.out.println("ArrayList Size "+states.size());

       // for(int i=0;i<states.size();i++){
           // System.out.println(states.get(i));
        //}
        //update Elements using .set() Method
        states.set(2, "Texas");
        System.out.println("After Updation : "+ states);

        //Removing Elements using .remove method

        String t = states.remove(3);
        System.out.println("State Removed is "+t);
        System.out.println("ArrayList After Deletion "+states);
        
        // Let us sort the List using .sort() Method
        states.sort(Comparator.naturalOrder()); //A-Z -> a-z
        
        System.out.println("ArrayList After Sorting "+states);
       // .contains() Method
       System.out.println("Is NewYork There ? "+states.contains("newyork"));
      //you can check if list is empty or not using .isEmpty() Method
      System.out.println("Texas is at "+states.indexOf("Texas")+" index");
      System.out.println("Is List Empty ?"+states.isEmpty());
      states.removeAll(states);
      System.out.println("Is List Empty ?"+states.isEmpty());


    }
}