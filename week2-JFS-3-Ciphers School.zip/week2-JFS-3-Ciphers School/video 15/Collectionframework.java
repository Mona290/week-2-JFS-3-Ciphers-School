import java.util.ArrayList;
import java.util.List;

public class Collectionframework{
    public static void main(String[] args){
        ArrayList cart0=new ArrayList();
        List cart1=new ArrayList();
        cart0.add("Apple");
        cart0.add(100);
        cart0.add('c');
        
        ArryList<Integer> cart2=new ArrayList<Integer>();
        cart0.add(100);
        cart0.add(800);
        System.out.println("ArrayList: "+states);

    }
}