import java.io.fileWrite;
import java.io.IOException;

public class IOTest3{
    public sttaic void main(String[] args) throws IOException{
        FileWriter fw=new FileWriter("C:\Users\shubham raina\Desktop\week2-JFS-3-Ciphers School\Video 18\myTestFile.txt");

        fw.write("Thanos is INEvitable");
        fw.flush();
        fw.close();
        System.out.println("File prepared Successfully!");
    }
}