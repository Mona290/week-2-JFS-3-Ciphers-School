import java.io.File;
public class IOTest {

    public static void main(String[] args){
        File f=new File("C:\Users\shubham raina\Desktop\week2-JFS-3-Ciphers School\Video 18\myTestFile.txt.txt");

        if(f.exists()) {
            System.out.println("File Name : "+f.getName());
            
            System.out.println("Printing File Details");
            System.out.println("------------------------");

            System.out.println("File Name : "+f.getName());
            System.out.println("File Size : "+f.length());
            System.out.println("File Path : "+f.getAbsolutePath());
            System.out.println("is File Readable ? "+f.canRead());
            System.out.println("is File Writable ? "+f.canWrite());

            System.out.println("------------------------");
       }
       File f1=new File("C:\Users\shubham raina\Desktop\week2-JFS-3-Ciphers School\Video 18\Avengers");
       f1.mkdir();
}