public class IOTest2 {
    public static void main(String[] args) throws IOException {
        FileWriter fw = new FileWriter("C:\Users\shubham raina\Desktop\week2-JFS-3-Ciphers School\Video 18\myTestFile.txt");

        fw.write("I am The Earth \n");
        fw.write("I am The Forest Green \n");
        fw.write("I am The four Winds Blowing  \n");
        fw.write("I am The Earth \n");

        fw.flush();
        fw.close();
        System.out.println("File Prepared Successfully!");

    }
}