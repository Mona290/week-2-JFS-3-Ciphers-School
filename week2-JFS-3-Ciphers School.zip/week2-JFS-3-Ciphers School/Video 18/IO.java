public class IO {
    public static void main(String[] args){


        File f=new File("C:\Users\shubham raina\Desktop\week2-JFS-3-Ciphers School/myTestFile.txt");

        try{
            f.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("File Created Successful!!!");
    }
}